<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="./css/main.css" />
<title>modul 2 opgave 3 - Resource type</title>
</head>

<body>

	<div class="container">