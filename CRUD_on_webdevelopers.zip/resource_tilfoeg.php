

<?php
include 'includes/dbcon.php';
$pid = filter_input(INPUT_POST, 'fid', FILTER_VALIDATE_INT) or die('missing parameter');
$rid = filter_input(INPUT_POST, 'cid', FILTER_VALIDATE_INT) or die('missing parameter');

require_once 'dbcon.php';
$sql = 'INSERT INTO film_category (category_id, film_id) VALUES (?,?)';
$stmt = $link->prepare($sql);
$stmt->bind_param('ii', $cid, $fid);
$stmt->execute();

?>

Film added to category

<a href="filmdetails.php?fid=<?=$fid?>">Filmdetails</a> 



</body>
</html>